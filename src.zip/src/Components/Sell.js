import React, { useState, useEffect } from "react";
import Dropdown from "./Dropdown";
import styled from "styled-components";
import Ewaste from "../Json Files/Ewaste";
import { Container } from "@mui/material";
function Sell() {
  //all the variables for forms
  const [EwasteValue, SetEwasteValue] = useState("");
  const [BrandValue, SetBrandValue] = useState("");
  const [modelSelect, setModelSelect] = useState(false);
  const [brandList, setBrandList] = useState([]);
  const [obj1, setobj1] = useState({});
  const [obj2, setobj2] = useState({});
  const [ModelList, setModelList] = useState([]);
  const [ModelValue, setModelValue] = useState({});
  const [finalStatus, setFinalStatus] = useState(false);
  const Ewastedata = [];

  Ewaste.map((ele) => Ewastedata.push(ele.name));
  Ewastedata.push("N/A");

  useEffect(() => {
    if (EwasteValue !== "") {
      const tempObj = Ewaste.find(({ name }) => name === EwasteValue);
      setobj1(tempObj);
    }
  }, [EwasteValue]);

  useEffect(() => {
    if (obj1.refurbishment === "yes") {
      setModelSelect(true);
      const brands = obj1.company.map((ele) => ele.name);
      setBrandList(brands);
    } else {
      setModelSelect(false);
    }
  }, [obj1]);

  useEffect(() => {
    if (BrandValue != "") {
      const tempObj = obj1.company.find(({ name }) => name === BrandValue);
      setobj2(tempObj);
    }
  }, [BrandValue]);
  useEffect(() => {
    if (BrandValue !== "") {
      const Models = obj2.models.map((ele) => ele.name);
      setModelList(Models);
      setFinalStatus(true);
    }
  }, [obj2]);

  return (
    <Container1>
      <NavBarHelp></NavBarHelp>
      <Heading>PROVIDE DETAILS ABOUT YOUR PRODUCT</Heading>
      <Main>
        <Info>
          <Context>Type of E-waste:</Context>
          <DropdownArea>
            <Dropdown
              data={Ewastedata}
              width={400}
              header={"Select One"}
              SetSelect={SetEwasteValue}
            />
          </DropdownArea>
        </Info>
        {modelSelect && (
          <>
            <Info>
              <Context>Brand:</Context>
              <DropdownArea>
                <Dropdown
                  data={brandList}
                  width={400}
                  header={"Select One"}
                  SetSelect={SetBrandValue}
                />
              </DropdownArea>
            </Info>
            <Info>
              <Context>Model:</Context>
              <DropdownArea>
                <Dropdown
                  data={ModelList}
                  width={400}
                  header={"Select One"}
                  SetSelect={setModelValue}
                />
              </DropdownArea>
            </Info>
          </>
        )}
        {finalStatus && <Submit>Submit</Submit>}
      </Main>
    </Container1>
  );
}

export default Sell;
const Container1 = styled.div`
  background-color: rgb(225, 235, 223);
  font-family: "Nunito", sans-serif;
  height: 115vh;
`;
const NavBarHelp = styled.div`
  height: 100px;
  width: 100%;
  background-image: linear-gradient(
    to bottom,
    rgb(79, 183, 73),
    rgb(79, 183, 73, 0.5)
  );
`;
const Heading = styled.div`
  font-size: 35px;
  margin-top: 50px;
  text-align: center;
  color: rgb(79, 183, 73);
  border-bottom: 2px solid;
`;
const DropdownArea = styled.div``;
const Context = styled.div``;
const Info = styled.div`
  display: flex;
  width: 600px;
  justify-content: space-between;
  align-items: center;
  margin: 30px;
`;
const Main = styled.div`
  margin-top: 50px;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
const Submit = styled.div`
  position: relative;
  top: 40px;
  padding: 10px;
  height: 20px;
  margin: 10px;
  color: rgb(79, 183, 73);
  border-radius: 5px;
  border: 2px solid rgb(79, 183, 73);
  transition: 400ms;
  cursor: pointer;
  z-index: 0;
  &:hover {
    color: white;
    background-color: rgb(79, 183, 73);
    border: 2px solid rgb(225, 235, 223);
    transform: scale(1.2);
  }
`;
