import React from "react";
import styled from "styled-components";
import iphone from "../images/Refusbished store/Iphone-14-PNG.png";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
function SmallCardArea() {
  const data = [
    {
      catagory: "Mobile Phones",
      data: [
        {
          name: "Samsung Galaxy S21",
          year: 2021,
          price: "8,000",
          specs: {
            ram: "8 GB",
            memory: "128 GB",
          },
          description: "8 GB Ram 128GB Storage",
          image:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1j_AeJgqHwb-1-ZwTYb3ISotvoPHzCOBxaf-_CCu8qaxZZbusLlmKD9NEROIk9mN1lx4&usqp=CAU",
        },
        {
          name: "Xiaomi Mi 11",
          year: 2021,
          price: "11,000",
          specs: {
            ram: "8 GB",
            memory: "128 GB",
          },
          description: "8 GB Ram 128GB Storage",
          image:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSoWr7AgR99rzvWD55thz6228q2P5KmAWOWDBUXH9IojOBkamiYj9mXE_R7bf_X6Du_1-k&usqp=CAU",
        },

        {
          name: "OnePlus 9",
          year: 2021,
          price: "14,000",
          specs: {
            ram: "8 GB",
            memory: "128 GB",
          },
          description: "8 GB Ram 128GB Storage",
          image:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwKyUb-eF7LNRtv9TfAM7mfwILFwh09VYbnWFjyb3I7mnQF5sCJggXLeKGXKbuRf3amGI&usqp=CAU",
        },
        {
          name: "Xiaomi Mi 10",
          year: 2020,
          price: "5,000",
          specs: {
            ram: "8 GB",
            memory: "128 GB",
          },
          description: "8 GB Ram 128GB Storage",
          image:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWHY6xelON0W2-V2XCbhHMo_bn8-joyMKlvHdN7H77tueiqhEBZwiP79YbvQITuoIqv2o&usqp=CAU",
        },
        {
          name: "Samsung Galaxy S20",
          year: 2020,
          price: "6,000",
          specs: {
            ram: "8 GB",
            memory: "128 GB",
          },
          description: "8 GB Ram 128GB Storage",
          image:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1j_AeJgqHwb-1-ZwTYb3ISotvoPHzCOBxaf-_CCu8qaxZZbusLlmKD9NEROIk9mN1lx4&usqp=CAU",
        },
      ],
    },
    {
      catagory: "Refrigerator",
      data: [
        {
          name: "Samsung RF28R7351SR",
          year: 2021,
          price: "40,000",
          specs: {
            capacity: "28 cu. ft.",
            type: "French Door",
            energy_rating: "ENERGY STAR Certified",
          },
          description:
            "28 cu. ft. capacity, French Door type, ENERGY STAR Certified energy rating",
          image:
            "https://www.nicepng.com/png/detail/255-2554930_samsung-bottom-freezer-and-french-doors-refrigerator-samsung.png",
        },
        {
          name: "Samsung RT18M6213SR",
          year: 2021,
          price: "25,000",
          specs: {
            capacity: "18 cu. ft.",
            type: "Top Freezer",
            energy_rating: "ENERGY STAR Certified",
          },
          description:
            "18 cu. ft. capacity, Top Freezer type, ENERGY STAR Certified energy rating",
          image:
            "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBgUFRUZGRgZGxoeGhoYGh0ZHhogGCAaGxgbGBsbIC0nICIpIxgZJjclKS4wNDQ0GiM5QTkyPi0yNDABCwsLEA8QHhISHTArIyMyNDIyOz47NzA+Pj4wMjswMjAyMjUwMDYyMjAwMjUyMjAyMjIyMj8yNTIyMDAyMDIwMv/AABEIAMUBAAMBIgACEQEDEQH/xAAbAAEBAAMBAQEAAAAAAAAAAAAAAQQFBgMCB//EAEQQAAEDAQUFBQYCBwYHAQAAAAECESEAAxITMUEEIlFxgUJhkaHBBQYjM0OxMnIUYmNzsuHxUlOSs8LTBxUkNFTR8IL/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EACQRAQEAAgIBBAEFAAAAAAAAAAABAhEDITEEEkGhIhNhcZHx/9oADAMBAAIRAxEAPwD9YWvE3UwRM+GnOl6MPXJ9ONFt9PPVuHXpSG/aeb/0oCF4e6qXmPDXlURZ4e8qXiPHXlVQzfEz0fh061EP9TLR+PTrQLs4mmba8KLs8TeTDRPjpzpL/qeTf1ot/p5atx69KCrXibqYaZ8NOdL0YeuT6caLb6eercOvSkN+083/AKUBC8PdVLzHhryqIs8PeVLxHjryqoZviZ6Pw6daiH+plo/Hp1oF2cTTNteFF2eJvJhonx050l/1PJv60WT9PLVuPXpQVa8TdTDTPhpzpejD1yfTjRbfTz1bh16VYb9fzf7ZUEQvD3VS8x4a8qiLPD3lS8R468qqG+pno/Dp1qIf6mWj8enWgXZxNM214UXZ4m8mGifHTnSX/Z+TUtL308tW49elBVrxN1MNM+GnOl6MPXJ9ONFt9PPVuHXpSG/X83/pQELw91UvMeGvKoizw95UvEeOvKqhm+Jno/Dp1qIf6mWj8enWgXZxOzm2vClpZ4m8mGifHTnSX/Z+TUW/08tW49elBVrxN1MNM+GnOl6MPXJ9ONFt9PPVuHXpSG/aeb/0oCF4e6qXmPDXlURZ4e8qXiPHXlVQzfEz0fh061EP9TLR+PTrQLs4mmba8KLs8TeTDRPjpzpL/qeTf1ot/p5atx69KCrXibqYaZ8NOdL0YeuT6caLb6eercOvSkN+083/AKUBacPeEvE+OnKl2MTXNtOFRCMPeVLxHjrypdnE7Oba8KCoRibyoaI8dedRFpibqoaY8NedLRGJvJhonx051VrxBdTDTPhpzoJenD0yfXjRdph7ol5nw05Vb8YfayfTjRCxZ7qpeY8NeVAWjD3ky8T46cqXYxNc204VEIw95UvEeOvKl2cTs5trwoCUYgKjBER4+tc5Y2cV0dojE3kwBE+OnOuL9rWykWmyhKlAKtmUASAoHDDKAMjeMHjVg2C7KvBdjW2XZ14Ls6qNLa2FYlpY1vLSyrwXs4uk68jx40GgtLKsZdnW5tbKsO0sqDVLRMu3dWt2+1s3XZpKwtIJIUCGAZ5ujiNa3ltZaVpLX2ZZ2ZVaIswlRBBI1eTGWYFUfs2wi5Y2axJNmgT+UH0rIuxia5tpwrG9mi5ZIWqQbNAj8oOvKsi7OJ2c214VhVQjEF5UNEeOvOoi0xN0w0x4a86WiMTeTDRPjpzqrXiC6mGmfDTnQS9OHpk+vGi7TD3Uy8z4acqt+MPtZPpxoheHuql5jw15UBaMPeTLxPjpypdjE1zbThUs0Ye8qXiPHXlS7OJ2c214UFQjE3lQ0R4686iLTE3VQ0x4a86WiMTeTDRPjpzqrXiC6mGmfDTnQS9OHpk+vGi7TD3RLzPhpyq34w+1k+nGiFiz3VS8x4a8qAtGHvJl4nx05Uuxia5tpwqIRh7ypeI8deVLs4nZzbXhQEP9TLR+PTrSX/Z+TURaYm6YaY8NedL04WmT68aAt/p5atx69Kq2+nnq3Dr0qLtMPdEvM+HpVWjD3hLxPj6UCG/X83/pRDfUz0fh060uxi65tpwohGJvGGiPHXnQRD/Uy0fj060l/wBn5NRFpibphpjw150vThaZPrxoC3+n+HVuPXuriPeAtabL3W3rYf8Auu3WvD3RLzPh6Vw/vCPibL+99dnqwdapFeS7Osopr4UmqjBXZ15LRuET/pzHnWetFYdog3sizcY8KDVWtnWJa2Vbm1s6w7WzoNHaorWbcjdNdDb2Najb7PdNB+lezXw7O/8AhuIZ+N0cO5695f8AU8m/rWP7ON+zs0GAEIMflA9ayL04WmT68ayot/p5atx69Kq2+nnq3Dr0qLtMPdEvM+HpVUjD3hLxPjpyoEN+083ohvqZ6Pw6daXYxNc204USjE3jDRHjrzoIh/qZaPx6daS/7PyaiLTE3TDTHhrzpenC0yfXjQFv9PLVuPXpVW3089W4delRdph7ol5nw9Kq0Ye8JeJ8fSgQ36/m/wDSiG+pno/Dp1pdjF1zbThRCMTeMNEeOvOgiH+plo/Hp1pL/s/JqItMTdMNMeGvOl6cLTJ9eNBV2mJupgiZ8NOdL8YfayfTjRbD5eerTHXpUhn+p5vy5UFQvDF1UkzHhryqWaDZ7ypBiPHXlVQx+Zno8R061EOfmZaPE9OtAul8Ts5trwotJtN5MARPjpzpLt9Pybnzotx8vLVpnr0oKu0xN1METPhpzpfjD7WT6caLYfLz1aY69KkM/wBTzflyoKlWGCFSTMeGtcT7wj4myn9p/q2cV2yGI+J+LR4jp3vXE+21fE2bvK/vYfyqwdiuvmhNWqjzUK81Jr2NfChQYtoisS0s6zl1j2goNZb2dab2ijdNdBbJrT+0kbp5UHbbIb9lZoTBShDv+UDTnWRfjD7WT6ca8dnDWaLmd1LtMXR6tXrDP9TzflyrKqheGLqpJmP58qlmg2e8qQYjx15VUsz2mejxHTrWIfaNkC1ta2YGgUtAnxoMq6XxOzm2vClog2m8mAInx0518WVuFKKUqBQMwCIHfrnX2tx8vLVpnr0oKu0xN1METPhpzpfjD7WT6caLYfLz1aY69KkM/wBTzflyoKheGLqpJmPDXlUs0Gz3lSDEeOvKqhj8zPR4jp1qIc/My0eJ6daBdL4nZzbXhRaTabyYAifHTnSXb6fk3PnRbj5eWrTPXpQVdpibqYImfDTnS/GH2sn040Ww+Xnq0x16VIZ/qeb8uVBVow94S8T4+lLsYuubacKiEGzlUgxE9+vKl0vidnNteGWVBUIxN4w0R4+tRC8TdMNMeHrUWk2m8mGiY79H419LtMQXUwRMx3aPxoJenC0yfXjRa8PdEvM+HpVvRh9rJ9OOedEWmHuqkmYnu1bhQFow94S8T4+lLsYmubacKiEGzlUgxE9+vKl0vidnNteGWVBUJxN4w0R46865T2dsFla2dnaW9ovESpdwhFnu3VqSGaz4JGfCupUk2hvJgCJjv051oPYdneskHvtP820oNiLNH/k2v+FH+1Xv+gft7bwR/t182uzgWauRrLSiGdozzbvlx41RjfoA/v7Xws/9un/Lx/f2vhZ/7deh2a7vKtlMkh7wsgNIJCAQ/MZ1j7Z7X2azQbRdugIDOQoKO87MEuSTdVAHZPCpvvQ+/wDlyf7618LP/br5Ps1H97a/4Uf7dar2N7xbLtdqqystotL8kJVZpQ4Gd0rs5bg7sOddFaWbBnPPI+TeVUss8tRabDYkFre0BIg3UluBbDmtBt3sS1UUps9oXbEg3hh2aAGY3lKIh8utdL+j/DSf1U/YV72CbiWSl7zE3j3CIAig01nsu3DK1s0BmYAE/wCWr70/5JtCy6trWDrdC28lp+1b029pwSOh/wDdfaCojPw5D1oOeX7pJUd+0Wttd0fxhR861/vJ7Gs7CyQUXrxWlJcvEnQAZgaV0+12igi0UFEFKYy0YnN61nv18pH71P2NSXY5r3s+bso47RZjxUgetfoSl4e6JeZ8PSuD960A2uxMN79MsJ7t4qHknwrvkLw4VJMxP35UBaMPeEvE+PpS7GLrm2nCpZoNnKpBiJ79eVLpfE7Oba8MsqCoRibxhojx9aiF4m6YaY8PWotJtN5MNEx36Pxr6XaYgupgiZju0fjQS9OFpk+vGi14e6JeZ8PSrejD7WT6cc86ItMPdVJMxPdq3CgLRh7wl4nx9KXYxNc204VEINnKpBiJ79eVLpfE7Oba8MsqAhz8z8OjxPTrRy7djybnRC8TdMNMeHrS9OFpk+vGgLcfLy1aZ69KqwAPh56tMdelRa8PdEvM+HpVWjD3hLxPj6UBgz9vzflyogA/Mz0eI6daXYxdc204UQjE3jDRHj60EQSfmZaPE9OtJdux5Nz50QvE3TDTHh60vThaZPrxoKpwfh/h1aZ69K0Xu0Rgo/Na/wCbaVvSvDN0S8z4elcz7BURYob+1a8P720/+61Rv/aFopNktSUX1BCiEAsVMMgWzrjPaXvF+kpVZ4akIBKSFu6i29+Eh8wAxcKIBzjqr9oUlyGbKP8A1X1abECTaLSh2crUhDsNSop0AHhXHlwyymsbpO/h+XWG3YYWBaKQFCzJQlw4KE3AoFKYktugcMnr39iDZV2Vv+kqdKlJuEFRWtQIPZLwpKGBLG9LxX6HZWVmpylKCBkUoQoEAO4IE19WdlZKNwGyKp3Gs7wZwd1nzBrhPTZefd2uVtu75fllui0srVdrYWZRcUQF7qSkXSSJWbMLZ2BJcgNmBXU7J7YBs7O0RaOtVob6d60tFXVXUJUUgsTupKgG3xDmuoUbAOk2lgCCxBNkGIggjiKyP0ICUhDwQQlGuRcCrlwZZa3l2W29177NNmj8ifsKwfa234KEqZSiV3QlABLNnlpGZGY1YH7s0Wos03Wa6GBYsGiWr32K2UxKngqyYPCcw2leuy66XGzfbR7N7XtbSzFphLQCCQF5gXroJCQYIBV4Vv8AZrMlN4qdxHd18awNoVeKQxKVFIUM4KSZfRyHr49nWJ3FBS0FVmoXVEG66kTGoZn0c1xwzzu9xvKY/C2+1WgvMhZ3VEB2diEpGUXiejTWP79fKR+9T9jWu9ve7otkLKtrWkJStTJW0tugsoZGQOOb1sPfgvY2Z42ifMGumFtm7NJnJL1dtT7bBVtexJH/AJBV1RZrUPWu3QAfmZ6PEdOtcftKH23Y1f2LS1UellaAeZFdghGJvGGiPH1rTCIc/My0eJ6daOXbseTc6IXibphpjw9aXpwtMn140Bbj5eWrTPXpVWAB8PPVpjr0qLXh7ol5nw9Kq0Ye8JeJ8fSgMGft+b8uVEAH5mejxHTrS7GLrm2nCiEYm8YaI8fWgiCT8zLR4np1pLt2PJufOiF4m6YaY8PWl6cLTJ9eNBVrFpupgiZju050vRh9rJ9OOedFsPl56tMdelIZ/qeb8qAhQs4VJMxP35VEINnKpBiJ79eVVDEfEz0eI6daiCT8zLR4np1oF0vidnNteGWVRaTaSiAImO/TnVcu30/JufOiyR8vLVpnr0oKtWJCYImY+3Ol6MPtZPpxzzoth8vPVpjr0owZ+35vyoLZqubqpJLxPdryrnfdhD2CPzWv+baV0NmAfmfi0eI6d71zfuxbBOzoKv7VrPBrW0d6o3+0smzWrglR8ATqR9xWs2b3gUsouWFooLUxUEboByVevM0gvwL1m7baBdkuzALrQtIcQ6kkB/GtL7E2Jdns4s130qRCNHSkJCSrDUQSQmZ45VjK2eI6YYyy2vLbjtNqbRVmLgUvdKgZTdKUlO72gkF9HrA24hKUqUhKFpQ6LynYi6pkEOQQkBs2LHWulQi7cO+q4om7IBDFIglhmC3dWYjCCysIAURJu7xgJzbgAOlebg9P+nnc93vf2zndyR+e2u27fapQiz2hSHVdUXaGBStS2yzBIOqRXmuy2tFmu0VaqvEEpVZrUFKuXmVaBQ1Ny7mXUAf7NdP7wnZ1ELsrSyxEFii8hL3SXBvKTdIJLyHyOVY1vsq7YizOzlFmpSVWi1Ls1O29dQEKJZwMw0vWMuPP3a+2Ph6+wvau0rRZC4XLFbgXbqpcrZnlmBOURI2vtL2Qm2SylrCb6mCFmzO8RqnMZeFZuyLCUJBB/CMkkjLSMq9VWm4pQeLzOGkDgRXrwx9s1btcbZ3Gu/5fuJQFLACUpBC2LJTdDqZ8hVs/ZoUFBSll0kOtZMEpJA0EpBdq+7HaFgpcrUAlpuG8SVspV1MndTkw3suHqra1JYkEhyDus5csM3DACWmtySeDbS2nu/YKCwbMKC0JBvMqBKdMxXr79fJR+8T9lV0NnaAu4I5g/eud9+/ko/eJ+yqSSdRbbfK7EkfpKFHsJtFfwp/1V0C0m0lMARMfbnWo9kpBtFEiAJPAEz9h4Vt1kj5eWrTPXpRFWoWkJgiZj7c6Xow+1k+nHPOiwB8vPVpjr0pDP9TzflQEKFnCpJmJ+/KohBs5VIMRPfryqoYj4mejxHTrUQSfmZaPE9OtAul8Ts5trwyyqLSbSUQBEx36c6rl2+n5Nz50WSPl5atM9elBVqxITBEzH250vRh9rJ9OOedFsPl56tMdelGDP2/N+VAWjD3hLxPj6Uuxi65tpwqISUSqQYifvypdL4nZzbXhlQVNnibxhojx9aiV4u6YaY8PWi0lcpgCJj7c6q1C0DIgiZj7c6CX5wtMn140WvD3RLzPh6Vb4bD7WT6cc6iFizhUkzE92vKgqkYe8JeJ8fSl2MXXNtOFRCSiVSDET9+VLpfE7Oba8MqC2aMTeMNEePrXLe7lmLTZkAuxNs4BIM2tpkRNdSpJWQpMARMd+lcx7pL+Ag/rW3+daVR5e0k2i0owxZvKiTaXJLM9xQJh4Lgv3ThbKrbQsK/6dIGd60/E5Di7iEDuJdmNdzbKNwgO5BZtS1fabYccuL6VzuEuW9tTLU9rVDa4HxEavNn0ZjzNZWxXFKUsEKUAEkg7sOoBsnkznvVnY6cn+/nXnb2wCFLdwAW4HQDximM1u7t2zWQEDhXjaWYmK53Z7Bk3L6yBZrQHUSQ6SAXd3gzJzyasRVvaJs7ZSlqPwykEnJ1pQVADXV+4VxvqsZ9/TVxsunU2I+Gj8qfsK812jJPepvFvR60Pu7tCzalKlqWDZgusgkXVBLBm4kks0p4Fs3bNrKUu3aKo/VuNXTj5ZyY+6M5T2+Xhb7Sh7MKTeC7S6RDb6VqAU+Y3CW7xWLsVki2uizTcKLdabzJDYZIWzdkgEAPkZFErQpW87pKVpTkxRZrQ8ZhynOsv2DZBKk3HYrXaF5/EFBTdVJiuuPhmWXw2a/Zlmm0NskKxCDN9RGQ7BN3QZCtJ7+fJR+9T9lV0+1WguqzgE5HTP71y3v4fgI/eJ/hXTdt7akk8Mv2Kp1rT/aAHmTW5WvD3RLzPh6VovYBddonVSQB4mt8hQs4VJMxP35UEUjC3hLxPj6VbsYuubacKiEmzlUgxE/flS6XxOzm2vDKgqbPE3jDRHj61Erxd0w0x4etFpK5TAETH251VqFoGRBEzH250EvzhaZPrxoteHuiXmfD0q3w2H2sn0451ELFnCpJmJ7teVBVIw94S8T4+lLsYuubacKiElEqkGIn78qXS+J2c214ZUBBJ+Zlo8T060cu3Y8m50SvE3TDTE93rS/OFpk+vGgLJHy8tWmevSqsAD4eerTHXpUK8LdEvMx3elFIwt4S8THf6UFYM/b835cqIAPzM9HiOnWl2MXXNvKibPE3jDRHj60EQSfmZaPE9OtHLt2PJudAvF3TDTE93rS/OFpk+vGgqiQRh/h1aZ69K5L3YSTs9m2V+3/zbRq62/hm6JeZju9K5f3QU2yo/Pb+VraUG12qyUuzKYGRcyzTlrT2f7HXZlSryVEpKcmYKIJGR4V57fti0p3Uo3jddZU0g5hPI61q9q2RdqqzXaKQTZqvIYmCxEukuNW4pSdK83Jy8eOX5TuJtv0bDaXgomzLF/wAKgc3gknVtPvWWpKyCCEsc5Ov/AOa0Nlb219KSq9eya0tAcieWh0rY2qbgBUspfMqtVpDtkHPOunFcLjfb4a3aI9mWkuoEXSBLM7734TM5ZRXgfY67q0rWDeSwIJTdm8CIzBAr0TbohrUF8vjKNfdpbhP47RKXb8Vozu39rvLVm8fFfif6tt+WN7M9mqsybS9fKkgC8WYFlHIameZPGvH2pY2hQQlG862BUACCzXTe7tWNZtn7RsgUoFpZuWupFokkjLdGtZNuAoMef2/l41vixxmOsNaZy/Ly5e02ZeIpSrJwAbpcrfuKULeWFZvsIlFoi/eS6LoSU2iUg7qu24fc5znW5VsCSAQTWOr2cRkquvxpmY68Mz2labivykDmWaud9/P+3R+8T/Cus222O1aC/B6wvf8AP/Tp/eJ/hXUjT293FOu0b8QSLvNzlXQoAPzM9HiOnWuZ911/EtFf2Ug+ZrpgjE3jDRE9/rQRBJ+Zlo8T060cu3Y8m50TaYm6YaYnu9aX5wtMn140BZI+Xlq0z16VVgAfDz1aY69KhXhbol5mO70opGFvCXiY7/SgrBn7fm/LlRAB+Zno8R060uxi65t5UTZ4m8YaI8fWgiCT8zLR4np1o5dux5NzoF4u6YaYnu9aX5wtMn140FWoLhEETMfbnS/FztZPpxzqLAT8vPVjejq/dRg176nm/wCWgqFCzDLkmYn78qiElErkGImc9eVEAK+Zno5ux0bvpZur5mWj7s9G76Axe/2c214ZUWCuUQBExOelJe72PJudFuPl5atvT1fuoKtQXCIImY+3Ol+LnayfTxqLAT8vPVjejq/dRg17t85f8vKgtmu5urkmQ092tcX7sbUEbNZJOZVtGhL3bW0JZh15A12lmAZtPxaPEch31+b+yrVrLZX1PtAnQ7otzDa51YOj27ahaWZQ4BcEFlFiOIbmOtYtmbQBryPFQ/01oSvabNKFWlssXgHUQleg0Izg5AuTWLtPtnaV2YUi13ApioMm8TAshhpCl2hcFkqAADrIDivDyY8eef5Y3cn8NfpV1uxqUi0FotaTde6A+oIJJPcTFZ+1+0wsBIKQc8yO7/4V+Y2PtO1tA1paLStDpKStRKXJIc5kyGUcw1dP7L9oWosCq5iqSLQISVhBUErs0gqWssACtbnglpInfDlx94SanlidOgVaOMkeA9QabUsLbdBIuAb6kgBKrxG6NRHpXJ7RtVvaKZSloOlnZlSQWgspMrkGXPdFYW0e07eyGHblRs3cC98RQDhr2ak6lJPDlWM8+L22Sb39usxyy8Oq2HZ1WSi10IcEJCiWbdS7oEBISM9M63mwbYm0tFJBcoRMENeKGzzyNfjXtJJFr+kWJFmpIBCiplE9lme8GGRzDBq/TfdPbMW2tbRmC9n2ZYHC+CSPIV29NMZh1NfsZ4XGS35den8I5UNBkKhru5vk1yvv9GzJ/eD+FddUa5T3/wD+2T+8H8K6QX3PPxLRWiUpJ8TXVLSVymAImPtzrkPcwvaWoORSm9yc6119o6fl5atvT1fuoKtQXCIImY+3Ol+LnayfTjnUWAn5eerG9HV+6jBr31PN/wAtBUKFmGXJMxP35VEJKJXIMRM568qIAV8zPRzdjo3fSzdXzMtH3Z6N30Bi9/s5trwyosFcogCJic9KS93seTc6LcfLy1benq/dQVaguEQRMx9udL8XO1k+njUWAn5eerG9HV+6qwa92+cvy5UBSMPeEvEx3+lLsYuubeWdRCSiVyDHH70ul7/Zzb+VASjF3jDRE9/rRK8XdMNPHu9aLSVyiAI4T0qrUFhkQRPCOlBL84WmT+eVCvC3RLzMd3pVvhrnayfzzohQRC5JnjHXlQRSMLeEvEx3+lW7GL1byzqISUSuQY4z15Uul7/Zzb+VB9JRibxhoie/1r8y9lkYexFcIK9vSpRe6m/+kJF46OS01+mKSVkKRAEHTv0rT+7fs1dhYiyvJWQq0U8pG+tSxDHK8B0qjjtss7NISlNobe6GvLtEJ0YkgBjwi7mXfOtUqyMWhAVaoUTZstIQHF0gJNowglyZJnQV+thZvXWS/Mt4tX1aWt2FJT0L+leXP02OXm3+/pfdbd1+P2OxJUtdpaIBWoiRaWYYAMAn4hENmZ3n0FbnZSizskWSSgEWNtulaFSu3Qq6VvdvmzKiATz1r9KtFFIdSU9C/pS8bt66luc/at4cGOMsm9a0l7fmq9qZThQUxLB0kEbzMN0AkXQ44AGBWF7YCbexBwmtmS5FogEORfD32IYqy6Ma/V7NRUHSlPUt6VLK1vQlI6/0rlfSYWy7vX7t8eWWE6r8D2n2LbqU6bMMwACrWz04OuB/Ov0b3IsrlraIcEJ2XZUFQcpK0JItAlXaYyW412ptN67dD/8A2rVz3vdse0rCMAIC0Eqc2ikmQRdDAM+d59Gaa9OGExmolytmq6IDryqE1w9pb+1tm/HZG0TxQpNsOoN20+9Sw/4gBKrlrZ3Vag3rNXRNoPU1pl25Ncr/AMQT/wBMn94P4bSs/ZvenZl5quH9YED/ABZVqPfvarNeyi4oK+IDE5ptGmqPr3IU9paJ/tJSPM12JXhbol5mO70rivcVT2lqnUoS3jXbIUEBlyTPGOtQCjD3hLxMd/pS7GLrm3lnUQkolcgxxnrS6Xv9nNv5UBKMXeMNET3+tErxd0w08e71otJXKIAjhPSqtQWGRBE8I6UEvzhaZP55UK8LdEvMx3elW+GudrJ/POiFBELkmeMdeVBFIwt4S8THf6VbsYvVvLOohJRK5BjjPXlS6Xv9nNv5UBBKvmZaPuzzjvo5e72PJvzfzoF4m6YaePd60v8A0uj+eVAtCUxZ5atvTznuosBI+HnqxvR591FLwt0S88O70obPC3hLxw7/AEoKwa92/N/y8qiAFTaZ6Puxyjvq3fq9W8s6gs8XeMNHHv8AWgIJV8zLR92ecd9HL3ex5N+b+dErxd0w08e71pf+l0fzyoCyUxZ5atvTznuosBPy89WN6PPuopeFuiXnh3elU2eHvCXjh3+lAYNe7fm/5eVRACptM9HN2OUd9W79Xq3lnUFni7xho49/rQEEq+Zlo+7POO+jl7vY8m/N/OiV4u6YaePd60v/AEuj+eVAWSmLPLVt6efhVWAkPZ56sb0efdUUvC3RLzw7vShs8LeEvHDv9KAwa92+cv8Al5UQAqbTPRzdjlHfVu/V6t5Z1BZ4u8YaOPf60BBKvmZaPuzz8a8do2dNpuWiErsuCkhSW5kV7C0xd3Jp493rS/8AS6P55UHNe0fcjY1F7GzXZvmbBakh/wAsp8q0vtD3CtgCLDakWgPZtEXVAfns4P8Ahrv1Lwt0S88O70oUYW8JeOHf6UHO+7PsG12Za1rWgqUkBKUEkggvIKRpXRIAVNpno5ux5d9W79Xq3lnUFni7xho49/rQLMlXzMtH3Z8u+jl7vY8m/N/OiV4u6YaePd60v/S6P55UC0JTFnlq29POe6iwEj4eerG9Hn3UUvC3RLzw7vShs8LeEvHDv9KCsGvdvzf8vKogBU2mej7sco76t36vVvLOoLPF3jDRx7/WgIJV8zLR92ecd9HL3ex5N+b+dErxd0w08e71pf8ApdH88qD724MkNE6RoajfC72z1q0oGwykvM6zoK8thlReY1mrSgfU7ny0yqbdCg0RpFWlB6bdCQ0TpGhqN8LvbPWrSgbDKS8zrOgry2GVF5jWeFWlBPq9z5aZU26FBojSONWlB6bdCQ0TpGho3w+9s9aUoGwykvM6zoK8thlReY1mrSgfU7ny0yqbdCg0RpFWlB6bdCQ0TpGho3w+9s9aUoGwykvM6zoK8thlReY1nhVpQPqdz5aZVNuhQaI0irSg9NuDJDROkaGo3wu9s9atKBsMpLzOs6CvLYZUXmNZq0oH1O58tMqm3QoNEaRVpQem3QkNE6RoajfC72z1q0oP/9k=",
        },
        {
          name: "Samsung RF23M8070SR",
          year: 2020,
          price: "50,300",
          specs: {
            capacity: "23 cu. ft.",
            type: "French Door",
            energy_rating: "ENERGY STAR Certified",
          },
          description:
            "23 cu. ft. capacity, French Door type, ENERGY STAR Certified energy rating",
          image:
            "https://image-us.samsung.com/SamsungUS/home/home-appliances/refrigerators/french-doors/pdp/rf23m8070sr-aa/features/rf23m8070sraa-feature-06-counter-depth-ss-708-031517.jpg?$feature-benefit-jpg$",
        },
        {
          name: "Samsung RS27T5561SR",
          year: 2020,
          price: "38,000",
          specs: {
            capacity: "27 cu. ft.",
            type: "Side-by-Side",
            energy_rating: "ENERGY STAR Certified",
          },
          description:
            "27 cu. ft. capacity, Side-by-Side type, ENERGY STAR Certified energy rating",
          image:
            "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0PEA0NDQ0NDQ0NEA8NDQ0NDRANDQ0NFREYFhURFhMYHSggGBolHRUTITUhJS0rLi4uFx81OT8sNzQtLisBCgoKDg0NFg0PECsZHxkrKysrKys3NysrKysrLTcrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAMIBAwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABwECBAUGAwj/xABJEAACAQICBAgKBQoFBQAAAAAAAQIDBAURBhIxcyEiMjRRcXKzE0FSdJOxssHC0hQjJKHDBxYzRGGRkqPh4kNjgYOiNUJTYoL/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAWEQEBAQAAAAAAAAAAAAAAAAAAARH/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAW1JZJvoTf7jx8PPyI/xv5QMgGM7ifkR/jfylkryS/7I+kfygZgNdLEpL/DXpH8pjVsfjDNzpPJJNas0+HXjHxpeUBugaSGkCktaNF5Z5cM8n6jyqaS5f4H83+0DoAcvPTBL9Xfpf7TwlpxFfqsvSr5QOvBxctPor9Ul6ZfKVt9PYznTp/RZLwk4Qz8MnlrSSz5P7QOzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAedxyJ9mXqPFntX5E+zL1HgwLZHjM9ZHjMoxaxzekcc5Wjza1a+fA8k/q5LJ9K4c/wDRHR1TnNINttvvhYGVZ8h9p+48Lk9rPkPtP3HhcAay4MCqZ9c19Uo8VXnDPUlKOe3J5Zl9nXnOvba8pSyrUss3nl9ZE8Khfh36e331HvEQTUACAAAAAAAAAAAAAAAAAAAAAAAAAAAPO45E+zL1GM2ZNfkT7MvUYeYCTPGbL5M8Zsox6zOd0h222++Fm/rM53SGXGtd98DAzLN8R9p+45rEtMcMpVKlGpc6tSlJwnHwNZ5SW1ZqOTOis3xH2pHz7pvVksQvsnl9oqvYvLYEmVdMsMey5/k1vlMSppZhz2XH8qr8pEH0mflfch9Jn5X3IaJajpJYzlGEa+cpyjCK8HUWcm8ks3HpZucN/T22/o94iGcErSlc2ybzXh6HiX/liTLhvOLbf0e8iBNYAIAAAAAAAAAAAAAAAAAAAAAAAAAAA86/In2Zeo12sbKvyZ9mXqNLrgespHjORSUzxnMosqyOd0hfGtd/8EjeVZnPY/LjWu++CQGdZviPtSPn7Tn/AKhfb+r7bJ8tJcR9qRAWm3P73f1fbYHPgqCDPwHnNtvqPexJowznFtv6PeRIXwHnNtvqPexJowvnFrv6HeRKJrABAAAAAAAAAAAAAAAAAAAAAAAAAAAFlfkz7L9Ryl9eqjSq1pJyVKnOq4xyzajFvJfuOrrcmXZfqOAxypnaXS6bet3bA0+H/lDo13lC1uI51I0uPKnypbHwN8Bm4npTGhHXlQnJf+kl70ugjLA5asKzW2NRTj2kk0bC6q1akYyqtOLceBJJ7V+wDscN0wpXNy7RUK1Oai568nBwyUc8uB5+M9McnxrXffBI5HRzJYk3/lPuzpsZnx7XffhyKNjbT4r7TIH00f26839X22ThRnxX2mQbpi/t13vqvtsUaQoVBBnYFzm231DvYkz4Vzm184od5EhjAuc22+o97EmfCec2vnFDvYlE2AAgAAAAAAAAAAAAAAAAAAAAAAAAAACyryZdT9RGWL1c7a43FX2GSdV5Mup+oiTEav1Ffc1PYZRwOFcmv2vcja3C+pX/AM+tGrwrZVXTL3GwlUk46j1cuDYnnt6yD0wJ5X+f+W/YZ0GKT49rvvw5HOYPL7b/ALfws3eIT49rvvw5lGyhPgl2n7iE9L39tut9U9tkyKXK6/ciJdIUvpd3mk/rqntCjnShstVdC/chkuhfuRBZgPObbfUe9iTLhHObTzih3sSJsLS8PbZJfp6PeRJZwfnNp5xQ72JRNoAIAAAAAAAAAAAAAAAAAAAAAAAAAAAtqbJdT9RD08pwcJcmcXF5cHA1kyYamx9TIZjLgXUiwYdLBLaGerGfC83nNsveF0OiX8RkuRRsDFoYbRp1PDQUtfLVzcs1ll0C9fHtd9+HIyGzDu3x7bffhyAzpPhl1+5Ghu9GbOrOdWaqa9STnLKo0s3t4DdTfDLr9yLGwNC9E7LyavpWWvROy8mr6Vm9ZawNJR0Zs4ShUjGprQlGcc6ja1ovNfejo8G51aecUO9iYrMrBedWnnFDvYgTaACAAAAAAAAAAAAAAAAAAAAAAAAAAALZ7H1MhaL4F1Imqex9TIUjsXUiwVzKNgoyijMS75dtvvw5GUzEvOXbb78OQGXLa+v3FrKva+v3FrAoy1lzLWBazLwTnVn5xQ72JiMzME51Z+c0O9iBNYAMgAAAAAAAAAAAAAAAAAAAAAAAAAAKS2PqIUjsXUia5bGQrHYupFgoUZcUKLWYd7yrbffhyMxmHfcq233wSAyvG+v3FGV6esowLWUZcy1gWsy8D51Z+c0O9iYjMzA+d2fnNDvYgTUADIAAAAAAAAAAAAAAAAAAAAAAAAAACjIVjsXUiamQtHYuosFCjLihRazCvuVbb74JGczCv+Vb774JAZK8fWGVXj6yjAtZRlzLWBazMwPndn5zQ72JiMzMC53Z+cUO8iBNAAMgAAAAAAAAAAAAAAAAAAAAAAAAAABC0di6iaSF1sRYKFCpRlFrMLEOVb774JGcYd+uNb/sqp/8JAZEfH1hlY+PrDAtZay5lGBYzNwLndn5xQ7xGGzNwHndn5xQ7xATMADIAAAAAAAAAAAAAAAAAAAAAAAAAAAQhU0E0mjdRaqQqWbuOFRr0YSVt4XY84ZpuGezMm8AR9W/J3cSrynHEVStNdONBWzqV1SyWa8M55Z7eHVeX7TcW+g1pGEVUqV6k0kpTU9RSfTqrYdSAOWoaC2ajGM6lxUkllKbqKLk+nJLJFIaB2Wc3Kdeacs4JzS8HHJcVZLh4U3m+k6oAcx+Y1h03C/3f6D8xbHpuPS/0OnAHL/mLY+Vcel/oYuI6AUJU2ratVpVnKnlUqy8LBQ11r8VZZtx1kuHa0dkAIxw/wDJ5iEalSV1dW9WhHX8FTtlOnWqcWWonKaahw6vT4/9dVoJoRj30mhc4jUVrStqsKjoT+j153GXDwSpPKKTS4fuJjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//Z",
        },
        {
          name: "Samsung RF28T5021SR",
          year: 2020,
          price: "24,340",
          specs: {
            capacity: "28 cu. ft.",
            type: "French Door",
            energy_rating: "ENERGY STAR Certified",
          },
          description:
            "28 cu. ft. capacity, French Door type, ENERGY STAR Certified energy rating",
          image:
            "https://images.webfronts.com/cache/rdhjekvyyvut.jpg?imgeng=/w_500/h_500/m_letterbox_ffffff_100",
        },
      ],
    },
    {
      catagory: "Wires",
      data: [
        {
          name: "Insulation Wire",
          year: 2022,
          price: "20/m",
          image: "https://cdn.moglix.com/p/I/W/Q/d/MINIWQ84IZ2BF-xxlarge.jpg",
          description:
            "Copper metal Conductor 12 AWG wire size 600V voltage rating and PVC insulation material",
          specs: {
            metal_name: "Copper",
            metal_type: "Conductor",
            wire_size: "12 AWG",
            voltage_rating: "600V",
            insulation_material: "PVC",
          },
        },
        {
          name: "Aluminum Conductor",
          year: 2022,
          price: "10/m",
          image:
            "https://4.imimg.com/data4/SN/LN/MY-3071363/aac-all-aluminum-conductor-bare-500x500.png",
          description:
            "Aluminum metal Conductor 16 AWG wire size 250V voltage rating and PVC insulation material",
          specs: {
            metal_name: "Aluminum",
            metal_type: "Conductor",
            wire_size: "16 AWG",
            voltage_rating: "250V",
            insulation_material: "PVC",
          },
        },
        {
          name: "Grounding Wire",
          year: 2021,
          price: "25/m",
          image: "https://www.maltep.com/img/cms/Cables/cable_cuivre_nu_14.jpg",
          description:
            "Copper metal Grounding Wire 10 AWG wire size 800V voltage rating and XLPE insulation material",
          specs: {
            metal_name: "Copper",
            metal_type: "Grounding Wire",
            wire_size: "10 AWG",
            voltage_rating: "800V",
            insulation_material: "XLPE",
          },
        },
        {
          name: "Grounding Wire",
          year: 2020,
          price: "15/m",
          image:
            "https://4.imimg.com/data4/SN/LN/MY-3071363/aac-all-aluminum-conductor-bare-500x500.png",
          description:
            "Aluminum metal Grounding Wire 10 AWG wire size 600V voltage rating and PE insulation material",
          specs: {
            metal_name: "Aluminum",
            metal_type: "Grounding Wire",
            wire_size: "10 AWG",
            voltage_rating: "600V",
            insulation_material: "PE",
          },
        },
        {
          name: "Aluminum Conductor",
          year: 2021,
          price: "10/m",
          image:
            "https://4.imimg.com/data4/SN/LN/MY-3071363/aac-all-aluminum-conductor-bare-500x500.png",
          description:
            "Aluminum metal Conductor 20 AWG wire size 150V voltage rating and PE insulation material",
          specs: {
            metal_name: "Aluminum",
            metal_type: "Conductor",
            wire_size: "20 AWG",
            voltage_rating: "150V",
            insulation_material: "PE",
          },
        },
      ],
    },
  ];
  return (
    <Container>
      {data.map((ele) => {
        return (
          <>
            <Header>{ele.catagory}</Header>
            <Block>
              {ele.data.map((ele) => {
                return (
                  <Card>
                    <Title>{ele.name}</Title>
                    <Image>
                      <img src={ele.image} alt="pata nhi" />
                    </Image>
                    <Section3>
                      <DetailContainer>
                        <Details>{ele.description}.... </Details>
                        <Price> ₹ {ele.price}</Price>
                      </DetailContainer>
                      <AddToCart>
                        <Icon>
                          <ShoppingCartIcon />
                        </Icon>
                        <Text>Add to cart</Text>
                      </AddToCart>
                    </Section3>
                  </Card>
                );
              })}
            </Block>
          </>
        );
      })}
    </Container>
  );
}

export default SmallCardArea;
const Container = styled.div`
  width: 98.9vw;
  font-family: "Nunito", sans-serif;
  height: 600px;
`;
const Header = styled.div`
  color: rgb(79, 183, 73);
  margin-top: 80px;
  margin-left: 60px;
  font-size: 30px;
  font-family: "Nunito", sans-serif;
`;
const Block = styled.div`
  height: 280px;
  margin: 20px 60px;
  width: 1400px;
  display: flex;
  justify-content: space-around;
  align-items: center;
`;
const Card = styled.div`
  height: 90%;
  box-shadow: 0px 0px 32px -4px rgba(0, 0, 0, 0.75);
  width: 200px;
  padding: 20px;
  border-radius: 10px;
  background-color: white;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
`;
const Title = styled.div`
  font-size: 20px;
  margin-left: 15px;
`;
const Image = styled.div`
  height: 140px;
  img {
    object-fit: contain;
    height: 100%;
    width: 100%;
  }
`;
const Details = styled.div`
  font-size: 12px;
  max-width: 100px;
  max-height: 35px;
  overflow: hidden;
`;
const AddToCart = styled.div`
  font-size: 12px;
  padding: 2px;
  position: relative;
  left: 3px;
  display: flex;
  justify-content: center;
  cursor: pointer;
  box-sizing: border-box;
  background-color: rgb(215, 235, 213);
  border: 2px solid rgb(79, 183, 73);
  transition: 300ms;
  &:hover {
    border: 2px solid transparent;
    background-color: rgb(79, 183, 73);
    transform: scale(1.1);
  }
  align-items: center;
  border-radius: 5px;
`;
const Section3 = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 10px;
  margin-bottom: 5px;
`;
const Icon = styled.div``;
const Text = styled.div``;
const DetailContainer = styled.div``;
const Price = styled.div``;
